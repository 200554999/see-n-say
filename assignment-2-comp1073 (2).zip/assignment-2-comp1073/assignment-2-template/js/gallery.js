// Function to change the featured image and its description
function changeFeaturedImage(imageSrc, imageDescription, index) {
	var featuredImage = document.getElementById('featuredImage');
	var imageCaption = document.getElementById('imageCaption');
	var thumbnails = document.querySelectorAll('#thumbnailList img');

	// Reset styles for all thumbnails
	thumbnails.forEach((thumbnail, i) => {
		if (i === index) {
			thumbnail.style.background = 'none';
			thumbnail.style.filter = 'none'; // Remove grayscale effect
		} else {
			thumbnail.style.background = 'var(--bg-color)';
			thumbnail.style.filter = 'grayscale(100%)';
		}
	});

	featuredImage.src = imageSrc;
	imageCaption.textContent = imageDescription;
}